//
//  ContentBrowser.swift
//  MappedScriptures
//
//  Created by Student on 12/5/20.
//

import SwiftUI

struct ContentBrowser: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct ContentBrowser_Previews: PreviewProvider {
    static var previews: some View {
        ContentBrowser()
    }
}
