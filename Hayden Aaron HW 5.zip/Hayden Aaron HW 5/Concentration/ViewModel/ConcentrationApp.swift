//
//  ConcentrationApp.swift
//  Concentration
//
//  Created by Student on 9/9/20.
//

import SwiftUI

@main
struct ConcentrationApp: App {
    var body: some Scene {
        WindowGroup {
            EmojiConcentrationGameView(emojiGame: EmojiConcentrationGame())
        }
    }
}
